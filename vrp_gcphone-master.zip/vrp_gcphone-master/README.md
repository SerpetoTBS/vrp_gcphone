# VRP_GCPHONE

Този скрипт не е създаден от нас! |
This script is not created by us!

###### Трябват ви:
- [mysql-async](https://github.com/brouznouf/fivem-mysql-async)

###### Инсталиране:

1. Сваляте всичко от тук.
2. Поставяте файловете в папка resources.
3. Изпълнявате SQL файловете във вашата SQL база данни.
4. Подредете скриптовете в този ред:
  
    ``start gcphone``    
    ``start vrp_addons_gcphone``  

5. Пуснете сървъра.


###### Допълнително:

- Aко искате обажданията да работят , ползвайте Dunko's voice чата. 


- Не е преведен , превеждането става през JS файловете.
